#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/pwm.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"


#include "driverlib/systick.h"

#include "drivers/io.h"
#include "drivers/motor.h"

static volatile unsigned long g_ulTickCount;

void SysTickHandler () {
	;
}

int
main(void)
{ 
 //MotorInit
		#define SYSCTL_PERIPH_PWM0      0x00100010  // PWM
		ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0); 

   	#define SYSCTL_PWMDIV_1         0x00000000  // PWM clock is processor clock /1
		ROM_SysCtlPWMClockSet(SYSCTL_PWMDIV_1);

  	// Enable the GPIO ports used by the motor.
  	#define SYSCTL_PERIPH_GPIOD     0x20000008  // GPIO D
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);

  	//Moteur 2
	  //#define SYSCTL_PERIPH_GPIOH     0x20000080  // GPIO H
	  //ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOH);

		// Set up the pin muxing for the PWM pins
		//       #define GPIO_PD0_PWM0           0x00030001
    //       GPIOPinConfigure(GPIO_PD0_PWM0);
		*(int *)(0x40007000+0x0000052C)=1;
	
		//#define GPIO_PH0_PWM2           0x00070002
	  //Motor2 	  GPIOPinConfigure(GPIO_PH0_PWM2);
	  // Configure the PWM0 generator
	
		#define PWM0_BASE               0x40028000  // Pulse Width Modulator (PWM)
		#define PWM_GEN_0               0x00000040  // Offset address of Gen0
    #define PWM_GEN_MODE_UP_DOWN    0x00000002  // Up/Down count mode
		#define PWM_GEN_MODE_NO_SYNC    0x00000000  // Immediate updates
		//ROM_PWMGenConfigure(PWM0_BASE, PWM_GEN_0,
    //                    PWM_GEN_MODE_UP_DOWN | PWM_GEN_MODE_NO_SYNC);		
	  //GenConf en ASM : @PWM0=4002800+0x40 (offset PMW0CTL)
		//Attention, je fais qq chose differement qui emballe la pwm qd on arrete...
		//revoir le code de GenConf et les 3 reg. dessous...
		*(int *)(0x40028000+0x040)=2; //Mode up-down-up-down, pas synchro
		//GenConf en ASM : 0x60 = offset PWM0GENA) <= 0x0b //
		*(int *)(0x40028000+0x060)=0x0B; //en decomptage, qd comparateurA = compteur => sortie pwmA=0
											//en comptage croissant, qd comparateurA = compteur => sortie pwmA=1
		//GenConf en ASM : 0x64 = offset PWM0GENB) <= 0x0b0 //
		*(int *)(0x40028000+0x064)=0x0B0; //en decomptage, qd comparateurB = compteur => sortie pwmB=0
											//en comptage croissant, qd comparateurB = compteur => sortie pwmA=1

  	//#define PWM_PERIOD (ROM_SysCtlClockGet() / 16000)								
    //ROM_PWMGenPeriodSet(PWM0_BASE, PWM_GEN_0, PWM_PERIOD);
		*(int *)(0x40028000+0x050)=0x1F4;

    //Motor2 Configure the PWM1 generator
    //#define PWM_GEN_1               0x00000080  // Offset address of Gen1
		//Motor2		ROM_PWMGenConfigure(PWM0_BASE, PWM_GEN_1,
    //                    PWM_GEN_MODE_UP_DOWN | PWM_GEN_MODE_NO_SYNC);
    //Motor2 ROM_PWMGenPeriodSet(PWM0_BASE, PWM_GEN_1, PWM_PERIOD);
		// Configure the pulse widths for each PWM signal to initially 0%

    //#define PWM_OUT_0               0x00000040  // Encoded offset address of PWM0
    //ROM_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_0, 0);
		*(int *)(0x40028000+0x05C)=0x1F4;

    //Motor2		ROM_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_2, 0);
    // Initially disable the the PWM0 and PWM2 output signals.
		//#define PWM_OUT_0_BIT           0x00000001  // Bit-wise ID for PWM0
		//#define PWM_OUT_2_BIT           0x00000004  // Bit-wise ID for PWM2
    //ROM_PWMOutputState(PWM0_BASE, PWM_OUT_0_BIT | PWM_OUT_2_BIT, false); inutile, on va changer de suite
 
		// Enable the PWM generators.
    ROM_PWMGenEnable(PWM0_BASE, PWM_GEN_0);
		
		//Motor2		ROM_PWMGenEnable(PWM0_BASE, PWM_GEN_1);

		/*
		// Set the pins connected to the motor driver fault signal to input with
    // pull ups.
		#define GPIO_PORTD_BASE         0x40007000  // GPIO Port D
		#define GPIO_PIN_3              0x00000008  // GPIO pin 3
    ROM_GPIOPinTypeGPIOInput(GPIO_PORTD_BASE, GPIO_PIN_3);

	  #define GPIO_STRENGTH_2MA       0x00000001  // 2mA drive strength
		#define GPIO_PIN_TYPE_STD_WPU   0x0000000A  // Push-pull with weak pull-up
		ROM_GPIOPadConfigSet(GPIO_PORTD_BASE, GPIO_PIN_3, GPIO_STRENGTH_2MA,
                         GPIO_PIN_TYPE_STD_WPU);
		*/
		
    // Enable slow decay mode.
		#define GPIO_PIN_2              0x00000004  // GPIO pin 2
    //ROM_GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_2);
		*(int *)(0x40007000+0x00000500)= *(int *)(0x40007000+0x00000500) | 0x00000004;//2mA
		*(int *)(0x40007000+0x0000051C)= *(int *)(0x40007000+0x0000051C) | 0x00000004; //Standard GPIO
		*(int *)(0x40007000+0x00000400)= *(int *)(0x40007000+0x00000400) | 0x00000004;	//Output
    //ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_2, GPIO_PIN_2);
		*(int *) (0x40007000+(0x04<<2)) = 0x04; //Mise A 1 pour slow Decay

		// Initially configure the direction control and enable pins as GPIO and
    // set low.
		//#define GPIO_PIN_0              0x00000001  // GPIO pin 0
		//#define GPIO_PIN_1              0x00000002  // GPIO pin 1
    //ROM_GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_0 | GPIO_PIN_1);
		*(int *)(0x40007000+0x00000500)= *(int *)(0x40007000+0x00000500) | 0x00000003;//2mA
		*(int *)(0x40007000+0x0000051C)= *(int *)(0x40007000+0x0000051C) | 0x00000003; //Standard GPIO
		*(int *)(0x40007000+0x00000400)= *(int *)(0x40007000+0x00000400) | 0x00000003;	//Output
		
		
		//Motor2		ROM_GPIOPinTypeGPIOOutput(GPIO_PORTH_BASE, GPIO_PIN_0 | GPIO_PIN_1);
		//ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0 | GPIO_PIN_1, 0);
		*(int *) (0x40007000+(0x03<<2)) = 0x00; // 2 broches � 0
		//Motor2		ROM_GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_0 | GPIO_PIN_1, 0);

		// Enable the 12V boost
		#define GPIO_PIN_5              0x00000020  // GPIO pin 5
    //ROM_GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_5);
		*(int *)(0x40007000+0x00000500)= *(int *)(0x40007000+0x00000500) | 0x00000020;//2mA
		*(int *)(0x40007000+0x0000051C)= *(int *)(0x40007000+0x0000051C) | 0x00000020; //Standard GPIO
		*(int *)(0x40007000+0x00000400)= *(int *)(0x40007000+0x00000400) | 0x00000020;	//Output
		//ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_5, GPIO_PIN_5);
		*(int *) (0x40007000+(0x20<<2)) = 0x20; // 0n !




//***********************************************************
		// Set the motor duty cycle to 50%.
    // Duty cycle is specified as 8.8 fixed point : MotorSpeed(0, 50 << 8);
		// First, enable the PWM output in case it was disabled by the
    // previously requested speed being greater than 95%
		//ROM_PWMOutputState(PWM0_BASE, PWM_OUT_0_BIT, true);
		*(int *)(0x40028000+0x008)=0x1;
		
		// Make sure that output is not inverted : INUTILE ??
    //ROM_PWMOutputInvert(PWM0_BASE, PWM_OUT_0_BIT, false);
		
		// Set the pulse width to the requested value. Divide by two since
    // we are using 6V motors with 12V power rail.
		
		
	  //Motor2 MotorSpeed(1, 50 << 8);
		//ROM_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_0, ((PWM_PERIOD * 50<<8)/(100 << 8)));
		//*(int *)(0x40028000+0x05C)=0x18;
		//MotorRun(0);
		//ROM_GPIOPinTypePWM(GPIO_PORTD_BASE, GPIO_PIN_0);
		*(int *)(0x40007000+0x00000500)= *(int *)(0x40007000+0x00000500) | 0x00000001;//2mA
		*(int *)(0x40007000+0x0000051C)= *(int *)(0x40007000+0x0000051C) | 0x00000001; //Standard GPIO
		*(int *)(0x40007000+0x00000400)= *(int *)(0x40007000+0x00000400) | 0x00000001;	//Output
		//MANQUE GPIODIR SET (mode output+GPIO DIR MODE HW; et AFSEL...voir la fonction GPIODirModeSet
		//#define GPIO_O_AFSEL            0x00000420  // GPIO Alternate Function Select
		*(int *)(0x40007000+0x00000420)= *(int *)(0x40007000+0x00000420) | 0x00000001;	//Alternate function
		//Motor2 MotorRun(1);
		while(1) {
			;
		}       
}


//Code pour les leds (pour reprendre GPIO) 
#ifdef toto

  // LEDs sur broches 4 & 5
	//ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
	//((void (*)(unsigned long ulPeripheral))((unsigned long *)(((unsigned long *)0x01000010)[13]))[6])(0x20000020);
	*(int *) (0x400FE108)= *(int *)(0x400FE108)| 0x20;
	
//ROM_GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_4 | GPIO_PIN_5);
//((void (*)(unsigned long ulPort, unsigned char ucPins))((unsigned long *)(((unsigned long *)0x01000010)[4]))[15])(0x40025000, 0x00000010 | 0x00000020);
	//donc GPIO_PORTF_BASE=0x40025000
	//GPIO_PIN_4=0x00000010 et GPIO_PIN_5=0x00000020 donc ucPins = 0x0000030
// GPIOPinTypeGPIOOutput(unsigned long ulPort, unsigned char ucPins)
//   GPIOPadConfigSet(ulPort, ucPins, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD);
//			avec	GPIOPadConfigSet(unsigned long ulPort, unsigned char ucPins,
//                 unsigned long ulStrength, unsigned long ulPinType)
//	// Set the output drive strength.
/*
#define GPIO_STRENGTH_2MA       0x00000001  // 2mA drive strength
#define GPIO_STRENGTH_4MA       0x00000002  // 4mA drive strength
#define GPIO_STRENGTH_8MA       0x00000004  // 8mA drive strength
#define GPIO_STRENGTH_8MA_SC    0x0000000C  // 8mA drive with slew rate control	
		
#define GPIO_O_DR2R             0x00000500  // GPIO 2-mA Drive Select
#define GPIO_O_DR4R             0x00000504  // GPIO 4-mA Drive Select
#define GPIO_O_DR8R             0x00000508  // GPIO 8-mA Drive Select
#define GPIO_O_SLR              0x00000518  // GPIO Slew Rate Control Select
    HWREG(ulPort + GPIO_O_DR2R) = ((ulStrength & 1) ?
                                   (HWREG(ulPort + GPIO_O_DR2R) | ucPins) :
                                   (HWREG(ulPort + GPIO_O_DR2R) & ~(ucPins)));
		*/
		*(int *)(0x40025000+0x00000500) =  	(*(int *)(0x40025000+0x00000500)) | (0x00000030);										 
    for (a=0;a<1000;a++);
		/* HWREG(ulPort + GPIO_O_DR4R) = ((ulStrength & 2) ?
                                   (HWREG(ulPort + GPIO_O_DR4R) | ucPins) :
                                   (HWREG(ulPort + GPIO_O_DR4R) & ~(ucPins))); */
		*(int *)(0x40025000+0x00000504) = 	*(int *)(0x40025000+0x00000504) & (~(0x00000030));
    for (a=0;a<1000;a++);
		/* HWREG(ulPort + GPIO_O_DR8R) = ((ulStrength & 4) ?
                                   (HWREG(ulPort + GPIO_O_DR8R) | ucPins) :
                                   (HWREG(ulPort + GPIO_O_DR8R) & ~(ucPins))); */
		*(int *)(0x40025000+0x00000508) = *(int *)(0x40025000+0x00000508) &	(~(0x00000030));
    for (a=0;a<1000;a++);
		/* HWREG(ulPort + GPIO_O_SLR) = ((ulStrength & 8) ?
                                  (HWREG(ulPort + GPIO_O_SLR) | ucPins) :
                                  (HWREG(ulPort + GPIO_O_SLR) & ~(ucPins))); */
		*(int *)(0x40025000+0x00000518) = *(int *)(0x40025000+0x00000518) & (~(0x00000030));
    for (a=0;a<1000;a++);
		//
    // Set the pin type.
    //
		/*
    #define GPIO_PIN_TYPE_STD       0x00000008  // Push-pull
    #define GPIO_PIN_TYPE_STD_WPU   0x0000000A  // Push-pull with weak pull-up
    #define GPIO_PIN_TYPE_STD_WPD   0x0000000C  // Push-pull with weak pull-down
    #define GPIO_PIN_TYPE_OD        0x00000009  // Open-drain
    #define GPIO_PIN_TYPE_OD_WPU    0x0000000B  // Open-drain with weak pull-up
    #define GPIO_PIN_TYPE_OD_WPD    0x0000000D  // Open-drain with weak pull-down
    #define GPIO_PIN_TYPE_ANALOG    0x00000000  // Analog comparator
    
		#define GPIO_O_ODR              0x0000050C  // GPIO Open Drain Select
    #define GPIO_O_PUR              0x00000510  // GPIO Pull-Up Select
    #define GPIO_O_PDR              0x00000514  // GPIO Pull-Down Select
    #define GPIO_O_DEN              0x0000051C  // GPIO Digital Enable
    HWREG(ulPort + GPIO_O_ODR) = ((ulPinType & 1) ?
                                  (HWREG(ulPort + GPIO_O_ODR) | ucPins) :
                                  (HWREG(ulPort + GPIO_O_ODR) & ~(ucPins)));
																	*/
		*(int *)(0x40025000+0x0000050C)= *(int *)(0x40025000+0x0000050C) & (~0x00000030);
		for (a=0;a<1000;a++);
    /* HWREG(ulPort + GPIO_O_PUR) = ((ulPinType & 2) ?
                                  (HWREG(ulPort + GPIO_O_PUR) | ucPins) :
                                  (HWREG(ulPort + GPIO_O_PUR) & ~(ucPins))); */
		*(int *)(0x40025000+0x00000510)= *(int *)(0x40025000+0x00000510) & ~(0x00000030);
		for (a=0;a<1000;a++);
    /* HWREG(ulPort + GPIO_O_PDR) = ((ulPinType & 4) ?
                                  (HWREG(ulPort + GPIO_O_PDR) | ucPins) :
                                  (HWREG(ulPort + GPIO_O_PDR) & ~(ucPins))); */
		*(int *)(0x40025000+0x00000514)= *(int *)(0x40025000+0x00000514) & ~(0x00000030);															
		for (a=0;a<1000;a++);
    /* HWREG(ulPort + GPIO_O_DEN) = ((ulPinType & 8) ?
                                  (HWREG(ulPort + GPIO_O_DEN) | ucPins) :
                                  (HWREG(ulPort + GPIO_O_DEN) & ~(ucPins))); */
		*(int *)(0x40025000+0x00000514)= *(int *)(0x40025000+0x00000514) | 0x00000030; //BIZARRE CAR PAS PUSH PULL...
		for (a=0;a<1000;a++);
		/*
    //
    // Set the analog mode select register.  This register only appears in
    // DustDevil-class (and later) devices, but is a harmless write on
    // Sandstorm- and Fury-class devices.
    //
				 #define GPIO_O_AMSEL            0x00000528  // GPIO Analog Mode Select
				 #define GPIO_PIN_TYPE_ANALOG    0x00000000  // Analog comparator
				HWREG(ulPort + GPIO_O_AMSEL) =
        ((ulPinType == GPIO_PIN_TYPE_ANALOG) ?
         (HWREG(ulPort + GPIO_O_AMSEL) | ucPins) :
         (HWREG(ulPort + GPIO_O_AMSEL) & ~(ucPins))); */
		*(int *)(0x40025000+0x00000528)= *(int *)(0x40025000+0x00000528) | (~0x00000030); 
				 
				 
  /*=============================================================================
  GPIODirModeSet(ulPort, ucPins, GPIO_DIR_MODE_OUT);
		GPIODirModeSet(unsigned long ulPort, unsigned char ucPins,
               unsigned long ulPinIO)
 #define GPIO_O_DIR              0x00000400  // GPIO Direction
 #define GPIO_DIR_MODE_OUT       0x00000001  // Pin is a GPIO output
 #define GPIO_O_AFSEL            0x00000420  // GPIO Alternate Function Select
 
 HWREG(ulPort + GPIO_O_DIR) = ((ulPinIO & 1) ?
                                  (HWREG(ulPort + GPIO_O_DIR) | ucPins) :
                                  (HWREG(ulPort + GPIO_O_DIR) & ~(ucPins))); */
	*(int *)(0x40025000+0x400) = 	*(int *)(0x40025000+0x400) | 0x00000030;														
	for (a=0;a<1000;a++);															
/* HWREG(ulPort + GPIO_O_AFSEL) = ((ulPinIO & 2) ?
                                    (HWREG(ulPort + GPIO_O_AFSEL) | ucPins) :
                                    (HWREG(ulPort + GPIO_O_AFSEL) &
                                     ~(ucPins)));		*/															
	*(int *)(0x40025000+0x420) = 	*(int *)(0x40025000+0x420) & ~0x00000030;
	for (a=0;a<1000;a++);
  while(1) {
 		//ROM_GPIOPinWrite(GPIO_PORTF_BASE, 0x10, 0x10);
		*(int *) (0x40025000+(0x10<<2)) = 0x10;
		*(int *) (0x40025000+(0x20<<2)) = 0x00;
		
		//ROM_GPIOPinWrite(GPIO_PORTF_BASE, 0x20, 0x00);
// 		ROM_GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4 | GPIO_PIN_5,
//                       ~ROM_GPIOPinRead(GPIO_PORTF_BASE,
//                                        GPIO_PIN_4 | GPIO_PIN_5));
//  GPIOPinWrite(unsigned long ulPort, unsigned char ucPins, unsigned char ucVal)  
//	{ HWREG(ulPort + (GPIO_O_DATA + (ucPins << 2))) = ucVal;	} avec #define GPIO_O_DATA             0x00000000  // GPIO Data
//    HWREG(GPIO_PORTF_BASE+ 0 + 		
//	*(int *) (0x40025000+(0x10<<2) = 255;
//	*(int *) (0x4005D000+(0x10<<2) = 255;
		for (a=0;a<1000000;a++);
		
		
		//ROM_GPIOPinWrite(GPIO_PORTF_BASE, 0x10, 0x00);
		*(int *) (0x40025000+(0x10<<2)) = 0x00;
		//ROM_GPIOPinWrite(GPIO_PORTF_BASE, 0x20, 0x20);
		*(int *) (0x40025000+(0x20<<2)) = 0x20;
		
		for (a=0;a<1000000;a++);
	}
}
//========================================================================
void MainApresPreprocesseur(){
   int a=0,b=0;
	((void (*)(unsigned long ulPeripheral))((unsigned long *)(((unsigned long *)0x01000010)[13]))[6])(0x20000020);
	//donc SYSCTL_PERIPH_GPIOF = 0x20000020
	((void (*)(unsigned long ulPort, unsigned char ucPins))((unsigned long *)(((unsigned long *)0x01000010)[4]))[15])(0x40025000, 0x00000010 | 0x00000020);
	//donc GPIO_PORTF_BASE=0x40025000
	//GPIO_PIN_4=0x00000010 et GPIO_PIN_5=0x00000020

  while(1) {
		((void (*)(unsigned long ulPort, unsigned char ucPins, unsigned char ucVal))((unsigned long *)(((unsigned long *)0x01000010)[4]))[0])(0x40025000, 0x00000010 | 0x00000020,
                      ~((long (*)(unsigned long ulPort, unsigned char ucPins))((unsigned long *)(((unsigned long *)0x01000010)[4]))[11])(0x40025000,
                                       0x00000010 | 0x00000020));
	 for (a=0;a<1000000;a++);
		b=b*2;
	}
}
#endif

		