/*
Pilotage Moteur Evalbot par PWM
*/
static volatile unsigned long g_ulTickCount;
void SysTickHandler () {
	;
}

int waitnop(int x){
	int i=0;
	int k=0;
	for (i=0;i<x;i++)
		k=i+k;
	return k;
}
int
main(void)
{  
	int a=125,b=500,c;

	//RCG0 = 0x400FE000+100, <= bit 20 = PWM recoit clock: ON (p271) 
	*(int *) (0x400FE100)= *(int *)(0x400FE100)| 0x00100000;

	//ROM_SysCtlPWMClockSet(SYSCTL_PWMDIV_1);PWM clock is processor clock /1
	//Je ne fais rien car par defaut = OK!!
	//*(int *) (0x400FE060)= *(int *)(0x400FE060)...;
	
  	//RCGC2 :  Enable port D GPIO 
	 *(int *) (0x400FE108)= *(int *)(0x400FE108) | 8;
		c=waitnop(a*b); //Il faut perdre 3 cycles!

		//Pin muxing pour PWM, port D, reg. GPIOPCTL(p444), 4bits de PCM0=0001<=>PWM (voir p1261)
		*(int *)(0x40007000+0x0000052C)=1;
		//Alternate Function Select
		*(int *)(0x40007000+0x00000420)= *(int *)(0x40007000+0x00000420) | 0x00000001;	//Alternate function
	
	  //GenConf en ASM : @PWM0=4002800+0x40 (offset PMW0CTL p1167)
		*(int *)(0x40028000+0x040)=2; //Mode up-down-up-down, pas synchro 
		//Control PWM0GENA 0x60 = offset PWM0GENA) <= 0x0b0 //en decomptage, qd comparateurA = compteur => sortie pwmA=0
	  //0B0=10110000 => ACTCMPBD=00 (B down:rien), ACTCMPBU=00(B up rien), 
		//ACTCMPAD=10 (A down:pwmA low), ACTCMPAU=11 (A up:pwmA high) , ACTLOAD=00,ACTZERO=00  
		*(int *)(0x40028000+0x060)=0x0B0; //en comptage croissant, qd comparateurA = compteur => sortie pwmA=1
		//Control PWMGENB 0x64 = offset PWM0GENB) <= 0x0b00 //en decomptage, qd comparateurB = compteur => sortie pwmB=0
		*(int *)(0x40028000+0x064)=0x0B00; //en comptage croissant, qd comparateurB = compteur => sortie pwmA=1

  	//#define PWM_PERIOD (ROM_SysCtlClockGet() / 16000), en mesure : SysCtlClockGet=0F42400h, /16=3E8, /2=1F4						
		*(int *)(0x40028000+0x050)=0x1F4; //PWM0LOAD=periode/2 
		*(int *)(0x40028000+0x05C)=0x1F4; //PWM0CMPB recoit meme valeur. (CMPA depend du rapport cyclique)
		// on divise par 2 car moteur 6v sur alim 12v
	  //pour 10% => 1C2h pour clock = 0F42400
		//pour 50% => plus petit, � calculer 0x192 = rapide!
	  *(int *)(0x40028000+0x058)=0x01C2;

		//PWM0CTL : active PWM Generator 0 (p1167): Enable+up/down + Enable counter debug mod
		*(int *) (0x40028000+0x40)= *(int *)(0x40028000+0x40) | 0x07;
		
    //  port D, pin 0 (pwm),1 (direct),2(slow decay),5(12v enable) config en sortie :
	  *(int *)(0x40007000+0x00000500)= 0x00000027;//2mA
		*(int *)(0x40007000+0x0000051C)= 0x00000027; //Standard GPIO
		*(int *)(0x40007000+0x00000400)= 0x00000027;	//Output
		*(int *) (0x40007000+(0x27<<2)) = 0x24; //puis mise � 1 de slow Decay et 12V, 0 pour dir et pwm

		//Enable PWM0 (bit 0), p1145
		*(int *)(0x40028000+0x008)=0x1;
		
		c=waitnop(10000000);
		while(1) {
					*(int *) (0x40007000+(0x2<<2)) = ~*(int *) (0x40007000+(0x2<<2)) ; //inverse dir
					c=waitnop(10000000);
					*(int *)(0x40028000+0x008)=0x0;
					c=waitnop(5000000);
					*(int *)(0x40028000+0x008)=0x1;
					c=waitnop(5000000);
			
			;
		}       
}

